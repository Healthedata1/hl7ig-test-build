# hl7.fhir.us.healthedata1-sandbox#0.1.0: Health eData 1 Sandbox

## Pages

* [Home](index.md)
* [Guidance](guidance.md)
* [ImplementationGuide Resource](ImplementationGuide.md)
* [Search Parameters](search-parameters.md)
* [Artifacts Summary](artifacts.md)
* [Change Log](changes.md)
* [Downloads](downloads.md)

## Resources

### Resource Profiles

* [US Core Observation ADI Documentation Profile](StructureDefinition-us-core-observation-adi-documentation.md)
* [US Core Observation Clinical Result Profile](StructureDefinition-us-core-observation-clinical-result.md)
* [US Core Laboratory Result Observation Profile](StructureDefinition-us-core-observation-lab.md)
* [US Core Patient Profile](StructureDefinition-us-core-patient.md)

### CapabilityStatements

* [US Core Client CapabilityStatement Liquid Rendered](CapabilityStatement-us-core-client-liquid.md)
* [US Core Server CapabilityStatement Liquid Rendered](CapabilityStatement-us-core-server-liquid.md)

### ImplementationGuides

* [Health eData 1 Sandbox](index.md)

### SearchParameters

* [USCoreObservationCategory](SearchParameter-us-core-observation-category.md)
* [USCoreObservationCode](SearchParameter-us-core-observation-code.md)
* [USCoreObservationDate](SearchParameter-us-core-observation-date.md)
* [USCoreObservationLastUpdated](SearchParameter-us-core-observation-lastupdated.md)
* [USCoreObservationPatient](SearchParameter-us-core-observation-patient.md)
* [USCoreObservationStatus](SearchParameter-us-core-observation-status.md)

### Examples

* [example (AllergyIntolerance)](AllergyIntolerance-example.md)
