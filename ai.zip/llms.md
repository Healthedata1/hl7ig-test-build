# hl7.fhir.us.healthedata1-sandbox#0.1.0: Health eData 1 Sandbox

## Pages

* [Home](index.md)
* [Guidance](guidance.md)
* [ImplementationGuide Resource](ImplementationGuide.md)
* [Search Parameters](search-parameters.md)
* [Versions](changes-between-versions.md)
* [Artifacts Summary](artifacts.md)
* [Profile and Extensions](profiles-and-extensions.md)
* [Scopes](scopes.md)
* [Change Log](changes.md)
* [IPA-IPS](relationship-with-other-igs.md)
* [Examples](examples.md)
* [Downloads](downloads.md)

## Resources

### Resource Profiles

* [US Core ADI DocumentReference Profile](StructureDefinition-us-core-adi-documentreference.md)
* [US Core AllergyIntolerance Profile](StructureDefinition-us-core-allergyintolerance.md)
* [US Core DocumentReference Profile](StructureDefinition-us-core-documentreference.md)
* [US Core Encounter Profile](StructureDefinition-us-core-encounter.md)
* [US Core Heart Rate Profile](StructureDefinition-us-core-heart-rate.md)
* [US Core Immunization Profile](StructureDefinition-us-core-immunization.md)
* [US Core MedicationRequest Profile](StructureDefinition-us-core-medicationrequest.md)
* [US Core Observation Pregnancy Status Profile](StructureDefinition-us-core-observation-pregnancystatus.md)
* [US Core Organization Profile](StructureDefinition-us-core-organization.md)
* [US Core PractitionerRole Profile](StructureDefinition-us-core-practitionerrole.md)
* [US Core QuestionnaireResponse Profile](StructureDefinition-us-core-questionnaireresponse.md)
* [US Core Specimen Profile](StructureDefinition-us-core-specimen.md)
* [US Core Vital Signs Profile](StructureDefinition-us-core-vital-signs.md)

### Extensions

* [US Core Birth Sex Extension](StructureDefinition-us-core-birthsex.md)
* [US Core Direct email Extension](StructureDefinition-us-core-direct.md)
* [US Core Ethnicity Extension](StructureDefinition-us-core-ethnicity.md)
* [US Core Individual Sex Extension](StructureDefinition-us-core-individual-sex.md)
* [US Core Jurisdiction Extension](StructureDefinition-us-core-jurisdiction.md)
* [US Core Race Extension](StructureDefinition-us-core-race.md)
* [US Core Sex Extension](StructureDefinition-us-core-sex.md)
* [US Core USCDI Requirement Extension](StructureDefinition-uscdi-requirement.md)

### CapabilityStatements

* [US Core Client CapabilityStatement Liquid Rendered](CapabilityStatement-us-core-client-liquid.md)
* [US Core Server CapabilityStatement](CapabilityStatement-us-core-server.md)

### ImplementationGuides

* [Health eData 1 Sandbox](index.md)

### OperationDefinitions

* [US Core Fetch DocumentReference](OperationDefinition-docref.md)

### SearchParameters

* [USCoreObservationCategory](SearchParameter-us-core-observation-category.md)
* [USCoreObservationCode](SearchParameter-us-core-observation-code.md)
* [USCoreObservationDate](SearchParameter-us-core-observation-date.md)
* [USCoreObservationLastUpdated](SearchParameter-us-core-observation-lastupdated.md)
* [USCoreObservationPatient](SearchParameter-us-core-observation-patient.md)
* [USCoreObservationStatus](SearchParameter-us-core-observation-status.md)

### Examples

* [example (AllergyIntolerance)](AllergyIntolerance-example.md)
* [docref-example-1 (Bundle)](Bundle-docref-example-1.md)
* [docref-example-2 (Bundle)](Bundle-docref-example-2.md)
* [discharge-summary (DocumentReference)](DocumentReference-discharge-summary.md)
