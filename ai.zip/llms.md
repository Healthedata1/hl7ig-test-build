# hl7.fhir.us.healthedata1-sandbox#0.1.0: Health eData 1 Sandbox

## Pages

* [Home](index.md)
* [Guidance](guidance.md)
* [ImplementationGuide Resource](ImplementationGuide.md)
* [Search Parameters](search-parameters.md)
* [Artifacts Summary](artifacts.md)
* [Change Log](changes.md)
* [Downloads](downloads.md)

## Resources

### Resource Profiles

* [US Core DiagnosticReport Profile for Laboratory Results Reporting](StructureDefinition-us-core-diagnosticreport-lab.md)
* [US Core Patient Profile](StructureDefinition-us-core-patient.md)

### CapabilityStatements

* [US Core Client CapabilityStatement Liquid Rendered](CapabilityStatement-us-core-client-liquid.md)
* [US Core Server CapabilityStatement Liquid Rendered](CapabilityStatement-us-core-server-liquid.md)

### ImplementationGuides

* [Health eData 1 Sandbox](index.md)

### SearchParameters

* [USCoreDiagnosticreportCategory](SearchParameter-us-core-diagnosticreport-category.md)
* [USCoreDiagnosticreportCode](SearchParameter-us-core-diagnosticreport-code.md)
* [USCoreDiagnosticreportDate](SearchParameter-us-core-diagnosticreport-date.md)
* [USCoreDiagnosticreportLastUpdated](SearchParameter-us-core-diagnosticreport-lastupdated.md)
* [USCoreDiagnosticreportPatient](SearchParameter-us-core-diagnosticreport-patient.md)
* [USCoreDiagnosticreportStatus](SearchParameter-us-core-diagnosticreport-status.md)
* [USCorePatientBirthdate](SearchParameter-us-core-patient-birthdate.md)
* [USCorePatientDeathDate](SearchParameter-us-core-patient-death-date.md)
* [USCorePatientFamily](SearchParameter-us-core-patient-family.md)
* [USCorePatientGiven](SearchParameter-us-core-patient-given.md)
* [USCorePatientId](SearchParameter-us-core-patient-id.md)
* [USCorePatientIdentifier](SearchParameter-us-core-patient-identifier.md)
* [USCorePatientName](SearchParameter-us-core-patient-name.md)

### Examples

* [example (AllergyIntolerance)](AllergyIntolerance-example.md)
