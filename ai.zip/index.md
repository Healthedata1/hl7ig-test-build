# Home - Health eData 1 Sandbox v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://hl7.org/fhir/us/healthedata1-sandbox/ImplementationGuide/hl7.fhir.us.healthedata1-sandbox | *Version*:0.1.0 | |
| *IG Standards status:*[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 2 | *Computable Name*:HealthEData_1Sandbox |
| **Copyright/Legal**: Used by permission of HL7 International, all rights reserved Creative Commons License | | |

### Health eData Sandbox

testbed for ideas….

#### FOO

using http:

[US Core](http://hl7.org/fhir/us/core/STU4/index.html)

[FHIR](http://hl7.org/fhir/)

using https:

[US Core](https://hl7.org/fhir/us/core/STU4/index.html)

[FHIR](https://hl7.org/fhir/)

using path variable

[FHIR](http://hl7.org/fhir/R4/)

#### in list…:

using http:

* [US Core](http://hl7.org/fhir/us/core/STU4/index.html)
* [FHIR](http://hl7.org/fhir/)

using https:

* [US Core](https://hl7.org/fhir/us/core/STU4/index.html)
* [FHIR](https://hl7.org/fhir/)

#### in table…:

using http:

| |
| :--- |
| [US Core](http://hl7.org/fhir/us/core/STU4/index.html) |
| [FHIR](http://hl7.org/fhir/) |

using https:

| |
| :--- |
| [US Core](https://hl7.org/fhir/us/core/STU4/index.html) |
| [FHIR](https://hl7.org/fhir/) |

### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (hl7.fhir.us.healthedata1-sandbox.r4)](package.r4.tgz) and [R4B (hl7.fhir.us.healthedata1-sandbox.r4b)](package.r4b.tgz) are available.

bar This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (hl7.fhir.us.healthedata1-sandbox.r4)](package.r4.tgz) and [R4B (hl7.fhir.us.healthedata1-sandbox.r4b)](package.r4b.tgz) are available.  foo

### IG Dependencies

This IG Contains the following dependencies on other IGs.






### Global Profiles

*There are no Global profiles defined*

### Copyrights

```
This publication includes IP covered under the following statements.
<ul>
<li>This material contains content from <a href="http://loinc.org">LOINC</a>. LOINC is copyright &copy; 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the <a href="http://loinc.org/license">license</a>. LOINC&reg; is a registered United States trademark of Regenstrief Institute, Inc.<div data-fhir="generated" id="ipp_1" onClick="if (document.getElementById('ipp2_1').innerHTML != '') {document.getElementById('ipp_1').innerHTML = document.getElementById('ipp2_1').innerHTML; document.getElementById('ipp2_1').innerHTML = ''}"> <span style="cursor: pointer; border: 1px grey solid; background-color: #fcdcb3; padding-left: 3px; padding-right: 3px; color: black">Show Usage</span></div><div id="ipp2_1" style="display: none">
<ul>
<li><a href="http://terminology.hl7.org/3.1.0/CodeSystem-v3-loinc.html">LOINC</a>: <a href="StructureDefinition-us-core-adi-documentreference.html">USCoreADIDocumentReferenceProfile</a> and <a href="StructureDefinition-pediatric-weight-for-height.html">USCorePediatricWeightForHeightObservationProfile</a></li>
</ul>
</div></li>
<li>This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact <a href="https://www.snomed.org/get-snomed">https://www.snomed.org/get-snomed</a> or <a href="mailto:info@snomed.org">info@snomed.org</a>.<div data-fhir="generated" id="ipp_2" onClick="if (document.getElementById('ipp2_2').innerHTML != '') {document.getElementById('ipp_2').innerHTML = document.getElementById('ipp2_2').innerHTML; document.getElementById('ipp2_2').innerHTML = ''}"> <span style="cursor: pointer; border: 1px grey solid; background-color: #fcdcb3; padding-left: 3px; padding-right: 3px; color: black">Show Usage</span></div><div id="ipp2_2" style="display: none">
<ul>
<li><a href="http://hl7.org/fhir/R4/codesystem-snomedct.html">SNOMED Clinical Terms&amp;reg; (SNOMED CT&amp;reg;)</a>: <a href="StructureDefinition-us-core-allergyintolerance.html">USCoreAllergyIntolerance</a>, <a href="StructureDefinition-us-core-careplan.html">USCoreCarePlanProfile</a> and <a href="StructureDefinition-us-core-careteam.html">USCoreCareTeam</a></li>
</ul>
</div></li>
<li>This material derives from the HL7 Terminology (THO). THO is copyright &copy;1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: <a href="https://terminology.hl7.org/license.html">https://terminology.hl7.org/license.html</a><div data-fhir="generated" id="ipp_3" onClick="if (document.getElementById('ipp2_3').innerHTML != '') {document.getElementById('ipp_3').innerHTML = document.getElementById('ipp2_3').innerHTML; document.getElementById('ipp2_3').innerHTML = ''}"> <span style="cursor: pointer; border: 1px grey solid; background-color: #fcdcb3; padding-left: 3px; padding-right: 3px; color: black">Show Usage</span></div><div id="ipp2_3" style="display: none">
<ul>
<li><a href="http://terminology.hl7.org/7.0.1/CodeSystem-allergyintolerance-clinical.html">AllergyIntolerance Clinical Status Codes</a>: <a href="StructureDefinition-us-core-allergyintolerance.html">USCoreAllergyIntolerance</a></li>
<li><a href="http://terminology.hl7.org/7.0.1/CodeSystem-allergyintolerance-verification.html">AllergyIntolerance Verification Status</a>: <a href="StructureDefinition-us-core-allergyintolerance.html">USCoreAllergyIntolerance</a></li>
<li><a href="http://terminology.hl7.org/7.0.1/CodeSystem-v3-HL7DocumentFormatCodes.html">HL7 Document Format Codes</a>: <a href="StructureDefinition-us-core-adi-documentreference.html">USCoreADIDocumentReferenceProfile</a></li>
<li><a href="http://terminology.hl7.org/7.0.1/CodeSystem-v3-ParticipationFunction.html">ParticipationFunction</a>: <a href="StructureDefinition-us-core-careteam.html">USCoreCareTeam</a></li>
</ul>
</div></li>
<li>Using RxNorm codes of type SAB=RXNORM as this specification describes does not require  a UMLS license. Access to the full set of RxNorm definitions, and/or additional use of other RxNorm structures and information requires a UMLS license. The use of RxNorm in this specification is pursuant to HL7's status as a licensee of the NLM UMLS. HL7's license does not convey the right to use RxNorm to any users of this specification; implementers must acquire a license to use RxNorm in their own right.<div data-fhir="generated" id="ipp_4" onClick="if (document.getElementById('ipp2_4').innerHTML != '') {document.getElementById('ipp_4').innerHTML = document.getElementById('ipp2_4').innerHTML; document.getElementById('ipp2_4').innerHTML = ''}"> <span style="cursor: pointer; border: 1px grey solid; background-color: #fcdcb3; padding-left: 3px; padding-right: 3px; color: black">Show Usage</span></div><div id="ipp2_4" style="display: none">
<ul>
<li><a href="http://terminology.hl7.org/3.1.0/CodeSystem-v3-rxNorm.html">RxNorm</a>: <a href="StructureDefinition-us-core-allergyintolerance.html">USCoreAllergyIntolerance</a></li>
</ul>
</div></li>
</ul>
<!--$$1$$-->

```

This publication includes IP covered under the following statements.

* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/3.1.0/CodeSystem-v3-loinc.html): [USCoreADIDocumentReferenceProfile](StructureDefinition-us-core-adi-documentreference.md) and [USCorePediatricWeightForHeightObservationProfile](StructureDefinition-pediatric-weight-for-height.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [USCoreAllergyIntolerance](StructureDefinition-us-core-allergyintolerance.md), [USCoreCarePlanProfile](StructureDefinition-us-core-careplan.md) and [USCoreCareTeam](StructureDefinition-us-core-careteam.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [AllergyIntolerance Clinical Status Codes](http://terminology.hl7.org/7.0.1/CodeSystem-allergyintolerance-clinical.html): [USCoreAllergyIntolerance](StructureDefinition-us-core-allergyintolerance.md)
* [AllergyIntolerance Verification Status](http://terminology.hl7.org/7.0.1/CodeSystem-allergyintolerance-verification.html): [USCoreAllergyIntolerance](StructureDefinition-us-core-allergyintolerance.md)
* [HL7 Document Format Codes](http://terminology.hl7.org/7.0.1/CodeSystem-v3-HL7DocumentFormatCodes.html): [USCoreADIDocumentReferenceProfile](StructureDefinition-us-core-adi-documentreference.md)
* [ParticipationFunction](http://terminology.hl7.org/7.0.1/CodeSystem-v3-ParticipationFunction.html): [USCoreCareTeam](StructureDefinition-us-core-careteam.md)


* Using RxNorm codes of type SAB=RXNORM as this specification describes does not require a UMLS license. Access to the full set of RxNorm definitions, and/or additional use of other RxNorm structures and information requires a UMLS license. The use of RxNorm in this specification is pursuant to HL7's status as a licensee of the NLM UMLS. HL7's license does not convey the right to use RxNorm to any users of this specification; implementers must acquire a license to use RxNorm in their own right.

* [RxNorm](http://terminology.hl7.org/3.1.0/CodeSystem-v3-rxNorm.html): [USCoreAllergyIntolerance](StructureDefinition-us-core-allergyintolerance.md)


### using {{site.data.resources[resource_].description}}

by string

{{site.data.resources['ImplementationGuide/healthedata1-sandbox'].description | markdownify}}

with markdown filter

without markdown filter

0: John

1: Paul

2: George

3: Ringo

